package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import vista.Bottom;
import vista.Center;
import vista.Top;

public class ProcessGestor implements ActionListener{

	private Center cent;
	private Top vTop;
	private Bottom bot;
	private ArrayList<String> alum;
	private int opRes;
	JTextArea taResult=new JTextArea();
	
	public ProcessGestor(Top t, Center c,Bottom b) {
		
		
		vTop=t;
		cent=c;
		bot=b;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		String[]op= {"Aceptar","Guardar txt"};
		
		String linea;
		
		alum=new ArrayList<String>();
		
		if(!vTop.getTextField().getText().equals("")) {
			
			try {
				
				BufferedReader br=new BufferedReader(new FileReader(vTop.getTextField().getText()));
				
				while((linea=br.readLine())!=null) {
					alum.add(linea);
				}
				
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			opRes=JOptionPane.showOptionDialog(null, panelResult(
					(double)alum.size(),
					Integer.parseInt(bot.getGroupSize().getText()),
					Integer.parseInt(bot.getGruposDividir().getText())),
					"Resultado", 0, -1, null, op, null);
			
			if (opRes!=0) {
				JFileChooser fc=new JFileChooser();
				fc.showSaveDialog(null);
			    
				try {
					File fichero = fc.getSelectedFile();
					//FileWriter bw;
					FileWriter  bw = new FileWriter(fichero+".txt");
					
					if(fc.SAVE_DIALOG!=0) {
					
						
					//bw=new FileWriter(fichero+".txt");
					taResult.write(bw);
					bw.close();	
					JOptionPane.showMessageDialog(null,
					         "El archivo se ha guardado exitosamente",
					             "Informaci�n",JOptionPane.INFORMATION_MESSAGE);
					
						
					}
					
				}catch(NullPointerException e1) {
					e1.printStackTrace();
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null,
					        "Su archivo no se ha guardado",
					           "Advertencia",JOptionPane.WARNING_MESSAGE);
				}
				
			}
		}else {
			
			JOptionPane.showMessageDialog(null, "Debe elegir un archivo con una lista");
			
		}
		
				
	}

	private JPanel panelResult(double alumn, int tamGroup, int nGrupos) {
		
		JPanel pan=new JPanel();
		JScrollPane scroll=new JScrollPane(taResult);
		HashMap<Double,String> hmResult=new HashMap<Double,String>();
		
		taResult.setText(null);
		double[] aResult=new double[alum.size()];

		for(int i=0;i<alum.size();i++) {
			
			double rnd=Math.random();
			hmResult.put(rnd, alum.get(i));
			aResult[i]=rnd;
		}

		Arrays.sort(aResult);
				
		if(alumn%tamGroup==0) {
			
			int row=0;
			
			for(int i=1;i<=nGrupos;i++) {
				
				taResult.append("Grupo "+i+"\n");
				
				for(int j=1;j<=tamGroup;j++) {
					
					taResult.append(hmResult.get(aResult[row])+"\n");
					row ++;
					
					
				}
				
				if (row==aResult.length) {
					
					break;
					
				}
				
				taResult.append("\n");
				
			}	
			
		}else {
			
			int row=0;
			int count=0;
			
			if(alumn/tamGroup>nGrupos) {

				for(int i=1;i<=nGrupos;i++) {
					
					taResult.append("Grupo "+i+"\n");
					int j;
					
					for(j=1;j<=tamGroup;j++) {
						
						taResult.append(hmResult.get(aResult[row])+"\n");
						row ++;
						count++;
						
					}
					
					if(count>i+j) {
						
						for(int k=count;k<alum.size();k++) {
							
							taResult.append(hmResult.get(aResult[k])+"\n");
							
						}
						break;
												
					}else {
						
					taResult.append("\n");
					break;	
					
					}
					
				}
				
			}else {
				
				row=0;
				
				for(int i=1;i<=nGrupos;i++) {
					
					taResult.append("Grupo "+i+"\n");
					
					for(int j=1;j<=tamGroup;j++) {

						if (row==aResult.length) {
							
							break;
							
						}
						
						taResult.append(hmResult.get(aResult[row])+"\n");
						row ++;
						
					}

					
					taResult.append("\n");
					
				}	
				
			}
			
		}

		taResult.setEditable(false);
		taResult.setBorder(BorderFactory.createEtchedBorder());
		pan.add(taResult);
		pan.add(scroll);
		return pan;
		
	}
	
}
