package control;

import java.io.File;

import javax.swing.filechooser.FileFilter;

public class ImgFileFilter extends FileFilter{

	public boolean accept(File f) {
		// TODO Auto-generated method stub
		
		if (f.getPath().endsWith(".txt"))
			return true;
		else return false;
	}

	public String getDescription() {
		// TODO Auto-generated method stub
		return "Archivos de imagen";
	}
	
}
