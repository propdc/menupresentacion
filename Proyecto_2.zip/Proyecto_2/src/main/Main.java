package main;

import vista.Vista;

public class Main {
	
	public static void main(String[] args) {
		Vista v=new Vista();
	}
	
}
