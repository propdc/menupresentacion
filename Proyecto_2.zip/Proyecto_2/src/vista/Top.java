package vista;

import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

import control.GestorExaminar;

public class Top extends JPanel{

	private JTextField textField;
	private JButton jbExaminar;
	private Center cent;
	
	public Top (Center c) {
		
		cent=c;
		textField = new JTextField();
		textField.setPreferredSize(new Dimension(250,25));
		textField.setBorder(new BordesRedondos(7));
		jbExaminar = new JButton("Buscar lista");
		jbExaminar.setPreferredSize(new Dimension(150,25));
		jbExaminar.setBorder(new BordesRedondos(7));
		jbExaminar.addActionListener(new GestorExaminar(this,cent));
	
		
		setLayout(new FlowLayout(0,52,5));
		
		this.add(textField);
		this.add(jbExaminar);
			
	}
	
	
	
	public JTextField getTextField() {
		return textField;
	}



	public void setTextField (String textField) {
		this.textField.setText(textField);
	}
	
	public JButton getjbExaminar() {
		return jbExaminar;
	}

}
