package vista;

import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import control.ProcessGestor;

public class Bottom extends JPanel{

	private JFormattedTextField groupSize,gruposDividir;
	private JButton botonProcesar;
	private Top vTop;
	private Center cent;
	
	public Bottom(Top t,Center c) {
		
		vTop=t;
		cent=c;
		groupSize=new JFormattedTextField(new Integer(2));
		groupSize.setPreferredSize(new Dimension(50,25));
		groupSize.setBorder(new BordesRedondos(7));
		groupSize.setValue(new Integer(Integer.parseInt(groupSize.getText())));
		gruposDividir = new JFormattedTextField(new Integer(4));
		gruposDividir.setPreferredSize(new Dimension(50,25));
		gruposDividir.setBorder(new BordesRedondos(7));
		gruposDividir.setValue(new Integer(Integer.parseInt(gruposDividir.getText())));
		botonProcesar = new JButton("Procesar");
		botonProcesar.setPreferredSize(new Dimension(100,25));
		botonProcesar.setBorder(new BordesRedondos(7));

		add(new JLabel("Componentes del grupo "));
		add(groupSize);
		this.add(new JLabel("N� de grupos "));
		this.add(gruposDividir);
		this.add(botonProcesar);
		
		botonProcesar.addActionListener(new ProcessGestor(vTop,cent,this));
	}

	public JTextField getTextField() {return gruposDividir;}
	public JButton getBotonProcesar() {return botonProcesar;}

	public JTextField getGruposDividir() {
		return gruposDividir;
	}

	public JTextField getGroupSize() {
		return groupSize;
	}
	
	
	
}
