package vista;

import java.awt.BorderLayout;

import javax.swing.JFrame;

public class Vista extends JFrame{

	private Center c;
	private Top t;
	private Bottom b;
	
	public Vista() {
		
		c = new Center();
		t=new Top(c);
		b=new Bottom(t,c);
		
		setLayout(new BorderLayout());
		add(t,BorderLayout.NORTH);
		add(c,BorderLayout.CENTER);
		add(b, BorderLayout.SOUTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setLocationRelativeTo(null);
		setResizable(false);
		setVisible(true);
	}
	
}
