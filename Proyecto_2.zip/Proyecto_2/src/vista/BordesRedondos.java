package vista;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.border.Border;

public class BordesRedondos implements Border{
//implementar la clase Border obliga a sobrescribir 3 de los siguientes m�todos
	private int radio;
	
	//Constructor al que le pasaremos un radio para redondear las esquinas de un componente
	public BordesRedondos(int r) {
		this.radio=r;
	}
	
	@Override
	public Insets getBorderInsets(Component c) {
		return new Insets(this.radio, this.radio, this.radio, this.radio);
	}

	@Override
	public boolean isBorderOpaque() {
		return false;
	}

	@Override
	public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
		g.drawRoundRect(x, y, width-1, height-1, this.radio, this.radio);
	}

}
